const express = require('express');
const router = express.Router();

const signatureController = require('../controllers/signature-controller');
const storage = require('../helpers/storage-user');

// router.get('/get-all-signature', userController.getAllUsers);
router.post('/add-signature', signatureController.addSignature);
router.put('/edit-signature/:id',storage, signatureController.editSignature);
// router.delete('/delete-signature/:id', userController.deleteUser);

module.exports = router;