const {
    signatureModel
} = require('../model/signature-modal');

// const bcrypt = require("bcryptjs");
// const jwt = require("jsonwebtoken");



const Aws = require("aws-sdk");
const jwt = require("jsonwebtoken");
const mime = require("mime");

const s3 = new Aws.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID, // accessKeyId that is stored in .env file
    secretAccessKey: process.env.AWS_ACCESS_KEY_SECRET, // secretAccessKey is also store in .env file
});

const getAllSignature = async (req, res, next) => {
    try {
        const response = await signatureModel.find();
        res.status(200).json({
            error: false,
            message: "Record Found",
            response,
        });
    } catch (err) {
        next(err);
    }
};

const getSignature = async (req, res, next) => {
    try {
        let id = req.params.id
        const response = await patientModel.findById({
            _id: id,
        });
        res.status(200).json({
            error: false,
            message: "Record Found",
            response,
        });
    } catch (err) {
        next(err);
    }
};

const addSignature = async (req, res, next) => {
    try {
        const {
            medicalSuperintenderSignature,
            SAMCOSignature,
            AMSignature
        } = req.body
        const response = await signatureModel.insertMany([{
            medicalSuperintenderSignature,
            SAMCOSignature,
            AMSignature
        }, ]);
        res.status(200).json({
            error: false,
            message: "Registered Successfully",
            response: response[0],
        });
    } catch (err) {
        next(err);
    }
};

const editSignature = async (req, res, next) => {
    try {
        const {
            medicalSuperintenderSignature,
            SAMCOSignature,
            AMSignature,
            typeName
        } = req.body;
        if (req.file !== null && req.file !== undefined) {
            const params = {
                Bucket: process.env.AWS_BUCKET_NAME,
                Key: `images/signatures/${req.file.originalname}`,
                Body: req.file.buffer,
                ACL: "public-read-write",
                ContentType: "image/jpeg",
            };
            await s3.upload(params, async (error, data) => {
                if (error) {
                    res.status(404).json({
                        error: true,
                        message: "Error in Uploading Photo",
                        response: error
                    });
                } else {

                    if (typeName == "medicalSuperintenderSignature") {
                        await signatureModel.updateOne({
                            _id: req.params.id,
                        }, {
                            $set: {
                                medicalSuperintenderSignature: data.Location,
                            }
                        });
                    }
                    if (typeName == "SAMCOSignature") {
                        await signatureModel.updateOne({
                            _id: req.params.id,
                        }, {
                            $set: {
                                SAMCOSignature: data.Location,
                            }
                        });
                    }
                    if (typeName == "AMSignature") {
                        await signatureModel.updateOne({
                            _id: req.params.id,
                        }, {
                            $set: {
                                AMSignature: data.Location,
                            }
                        });
                    }
                    const response = await signatureModel.find();
                    res.status(200).json({
                        error: false,
                        message: "Department added Successfully",
                        response
                    });

                }
            });
        }
    } catch (err) {
        next(err);
    }
};

const deleteSignature = async (req, res, next) => {
    try {
        await patientModel.deleteOne({
            _id: req.params.id,
        });
        res.status(200).json({
            error: false,
            message: "Signature Deleted Successfully",
            _id: req.params.id,
        });
    } catch (err) {
        next(err);
    }
};

module.exports = {
    getAllSignature,
    // getSignature,
    addSignature,
    editSignature,
    // deleteSignature
};