const mongoose = require("mongoose");
const Schema = mongoose.Schema


const signatureSchema = new mongoose.Schema({
    medicalSuperintenderSignature: {
        type: String,
        required: true
    },
    SAMCOSignature: {
        type: String,
        required: true
    },
    AMSignature: {
        type: String,
        required: true
    }
});
signatureSchema.set('timestamps', true);


const signatureModel = mongoose.model('signature', signatureSchema);
module.exports = {
    signatureModel
};